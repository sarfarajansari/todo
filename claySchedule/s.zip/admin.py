from django.contrib import admin
from .models import Time,Day,Lecture
# Register your models here.

admin.site.register(Time)
admin.site.register(Day)
admin.site.register(Lecture)