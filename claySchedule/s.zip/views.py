from rest_framework.decorators import api_view
from rest_framework.response import Response
from datetime import datetime,timedelta
from .models import Lecture
from .serializer import responsedata
import pytz
# Create your views here.
@api_view(["GET"])
def index(request):
    lectures = Lecture.objects.all()
    Data=[]
    for lec in lectures:
        Data.append(responsedata(lec).data)
    return Response(Data)
